const { Client, Events, GatewayIntentBits } = require('discord.js');
const WHUtilities = require("../webhook/whutilties");


// Create a new client instance with specified intents
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
});

// Import the WHUtilities module

// Create a new instance of the webhook utility class with the provided webhook URL
const webhook = new WHUtilities(process.env['WHURL']);

// Define the DiscorBot class
class DiscorBot {

  /**
   * Constructor for DiscorBot
   * @param {string} token The Discord API token to be used for logging in
   */
  constructor(token) {
    this.token = token;
  }

  /**
   * Initialize the Discord bot
   */
  init() {
    // Listen for the `ClientReady` event and log a message when it fires
    client.once(Events.ClientReady, c => {
      console.log(`Ready! Logged in as ${c.user.tag}`);
    });

    // Log in to Discord with the provided API token
    try {
      client.login(this.token);
    } catch (error) {
      console.error('Error logging in:', error);

    }
  }

  /**
   * Listen for messages in Discord channels
   */
  listenForMessages() {
    // Listen for the `messageCreate` event and log a message when it fires
    client.on("messageCreate", (message) => {
      console.log("Message received: " + message.author.id);

      // Check if the message was written by the bot with ID 936929561302675456
      if (message.author.bot && message.author.id === '936929561302675456') {
        // Prepare the body of the webhook message
        var body = [
          {
            "id": message.id,
            "channel_id": message.channel.id,
            "content": "Download Link: ",
            "timestamp": new Date().toISOString(),
          }
        ]

        // Check if the message contains any attachments
        if (message.attachments.size > 0) {
          // Loop through each attachment and add its URL to the content of the webhook message
          message.attachments.forEach(attachment => {
            let attachmentURL = attachment.url;
            console.log(attachmentURL);
            body[0].content += attachmentURL;
            try {
              webhook.postImage(body);
            } catch (error) {
              console.error('Error posting to webhook:', error);
            }
          });
        }
      }
    });
  }
}

// Export the DiscorBot class for use in other modules
module.exports = DiscorBot;
