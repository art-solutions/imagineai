const axios = require('axios');

class WHUtilities {

    constructor(wh_url) {
        this.wh_url = wh_url;
    }

    async postImage(body) {
        try {
            const config = {
                method: "POST",
                data: body
            };
            const response = await axios(this.wh_url, config);
            return {
                response_code: response.status,
                response: response.data
            };
        } catch (error) {
            return {
                error: error.message
            };
        }
    }
}

module.exports = WHUtilities;
