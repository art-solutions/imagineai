const express = require('express')
const app = express()

const jwt = require("jsonwebtoken");


const bodyParser = require("body-parser");
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const ImagineRequestService = require("./midjourney/request")

const DiscorBot = require("./discord/discord")
const bot = new DiscorBot(process.env['BTOKEN']);

const userModel = require("./user/user");

console.log("creating table")



bot.init();
bot.listenForMessages();


app.use(bodyParser.json());
app.use(cors());
app.use(morgan('combined'));
app.use(helmet());


const verifyToken = (req, res, next) => {
  let token = req.header("Authorization");
  if (!token) {
    return res.status(401).json({ error: "Access denied, no token provided" });
  }

  try {
    token = token.slice(7);

    console.log(token);

    const decoded = jwt.verify(token, process.env['ACCESS_SECRET']);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(400).json({ error: "Invalid token" });
  }
};

const generateToken = user => {
  const accessToken = jwt.sign(
    { userId: user.id },
    process.env['ACCESS_SECRET'],
    { expiresIn: "15m" }
  );
  const refreshToken = jwt.sign(
    { userId: user.id },
    process.env['REFRESH_SECRET'],
    { expiresIn: "7d" }
  );
  return { accessToken, refreshToken };
};

app.post("/signup", (req, res) => {
  userModel.getUserByEmail(req.body.email, (error, user) => {
    if (error) {
      return res.status(500).send(error.message);
    }

    if (user) {
      return res.status(500).send("A user with that email already exists");
    }

    // Continue with creating a new user
    const newUser = {
      email: req.body.email,
      password: req.body.password
    };

    userModel.saveUser(newUser, (error, userId) => {
      if (error) return res.status(500).send(error.message);
      res.send({ userId });
    });
  });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  userModel.getUserByEmail(email, (error, user) => {
    if (error) {
      return res.status(500).json({ error });
    }
    if (!user) {
      return res.status(400).json({ error: "Incorrect email or password" });
    }
    userModel.comparePassword(password, user.password, (error, isMatch) => {
      if (error) {
        return res.status(500).json({ error });
      }
      if (!isMatch) {
        return res.status(400).json({ error: "Incorrect email or password" });
      }
      const { accessToken, refreshToken } = generateToken(user);
      res.status(200).json({
        message: "Login successful",
        accessToken,
        refreshToken
      });
    });
  });
});

app.post("/refresh-token", (req, res) => {
  let refreshToken = req.header("Authorization");

  if (!refreshToken) {
    return res.status(401).json({ error: "No refresh token provided" });
  }

  try {

    refreshToken = refreshToken.slice(7);

    const decoded = jwt.verify(refreshToken, process.env['REFRESH_SECRET']);
    const newAccessToken = jwt.sign({ email: decoded.email }, process.env['ACCESS_SECRET'], {
      expiresIn: "15m",
    });

    res.status(200).json({ accessToken: newAccessToken });
  } catch (error) {
    return res.status(401).json({ error: "Invalid refresh token" });
  }
});

app.post("/imagine", verifyToken, (req, res) => {
  const { image_prompt, text_prompt, parameter } = req.body;
  const request = new ImagineRequestService(image_prompt, text_prompt, parameter);

  try {
    request.requestCommand();
  } catch (error) {
    return res.status(400).send(error.message);
  }


  res.send("Data received");
});




app.listen(3000, () => {
  console.log(`server started on port 3000`);
});