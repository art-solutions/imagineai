const bcrypt = require("bcrypt");
const pool = require("../config/database");

const getUserById = (id, callback) => {
  pool.query(`SELECT * FROM users WHERE id = ?`, [id], (error, results) => {
    if (error) return callback(error);
    callback(null, results[0]);
  });
};

const getUserByEmail = (email, callback) => {
  pool.query(`SELECT * FROM users WHERE email = ?`, [email], (error, results) => {
    if (error) return callback(error);
    callback(null, results[0]);
  });
};

const saveUser = (user, callback) => {
  bcrypt.hash(user.password, 10, (error, hash) => {
    if (error) return callback(error);
    pool.query(
      `INSERT INTO users (email, password) VALUES (?, ?)`,
      [user.email, hash],
      (error, results) => {
        if (error) return callback(error);
        callback(null, results.insertId);
      }
    );
  });
};

const comparePassword = (candidatePassword, hash, callback) => {
  bcrypt.compare(candidatePassword, hash, (error, isMatch) => {
    if (error) return callback(error);
    callback(null, isMatch);
  });
};

const createTable = callback => {
  const query = `
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(255) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL
    );
  `;

  pool.query(query, error => {
    if (error) return callback(error);
    callback(null);
  });
};

module.exports = {
  getUserById,
  getUserByEmail,
  saveUser,
  comparePassword,
  createTable
};
