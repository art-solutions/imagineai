const axios = require('axios');

class ImagineRequestService {

  /**
    * Constructor for ImagineRequestService class
    * @param {string} image_prompt - The image prompt for the imagine request
    * @param {string} text_prompt - The text prompt for the imagine request
    * @param {string} parameter - Additional parameter for the imagine request
    */

  constructor(image_prompt, text_prompt, parameter) {
    this.image_prompt = image_prompt;
    this.text_prompt = text_prompt;
    this.parameter = parameter;
  }


  /**
 * Function to build the complete prompt
 * @returns {string} - The complete prompt (image_prompt + text_prompt + parameter)
 */
  buildPrompt() {
    console.log("Image" + this.image_prompt);
    console.log("Text" + this.text_prompt);
    console.log("Parameter" + this.parameter);

    let string = this.image_prompt + " " + this.text_prompt + " " + this.parameter;

    console.log("String " + string);

    return string;
  }

  /**
    * Function to generate the payload for the imagine request
    * @returns {object} - The payload object
    */
  genPayload() {
    let string = this.buildPrompt();
    console.log("Matches: " + string === "https://s.mj.run/I65RdCdthOg a gigantic horrifying monster shark, rises out of the stormy ocean and bites a pirate ship in a fantasy concept, the image evokes drama and horror, High quality, Illustration by Aaron J Riley, Bob Kehl, Stanley Artgerm Lau moody volumetric lighting --ar 16:9 --v 4 --q 4 --s 800)");
    return {
      type: 2,
      application_id: "936929561302675456",
      guild_id: process.env['GUILD_ID'],
      channel_id: process.env['CHANNEL_ID'],
      session_id: this.generateRandomString(32),
      data: {
        version: "994261739745050686", id: "938956540159881230", name: "imagine", type: 1, options: [{
          type: 3, name: "prompt", value: string
        }], application_command: {
          id: "938956540159881230",
          application_id: "936929561302675456",
          version: "994261739745050686",
          default_permission: true,
          default_member_permissions: null,
          type: 1,
          nsfw: false,
          name: "imagine",
          description: "There are endless possibilities...",
          dm_permission: true,
          options: [{
            type: 3, name: "prompt", description: "The prompt to imagine", required: true
          }]
        }
      },
      nonce: this.calculateNonce("now"),
    };
  }

  /**
     * Function to send the imagine  command
     * @returns {object} - The response from the request
     */
  requestCommand() {


    let randomStr = this.generateRandomString(16);
    let boundary = "----WebKitFormBoundary" + randomStr;

    let body = this.createMultipartEntity(this.genPayload(), boundary);

    const headerMods = {
      "Content-Type": `multipart/form-data; boundary=${boundary}`, "Authorization": process.env['UTOKEN'],
    }

    return this.sendRequest("POST", "https://discord.com/api/v9/interactions", body, headerMods);
  }

  /** 
  This method takes a JSON payload and a boundary string, and creates and returns the body of the request in the required multipart/form-data format.
  */

  createMultipartEntity(payload, boundary) {
    const lineBreak = "\r\n";
    const contentDisposition = `Content-Disposition: form-data; name="payload_json"${lineBreak}${lineBreak}`;

    const payloadJson = JSON.stringify(payload);

    return `--${boundary}${lineBreak}${contentDisposition}${payloadJson}${lineBreak}--${boundary}--${lineBreak}`;
  }

  /** 
  This method sends the request to the specified URL using the specified HTTP method (GET, POST, etc.). It takes four arguments: the method, the URL, the request body, and an object containing header modifications. The method uses the axios library to send the request and returns an object containing the response code and response data (or error message if an error occurred).
  */

  async sendRequest(method, url, body, headerMods) {
    const result = {};
    try {
      const config = {
        method: method.toUpperCase(), headers: headerMods, data: body,
      };
      const response = await axios(url, config);
      result.response_code = response.status;
      result.response = response.data;
    } catch (error) {
      result.error = error.message;
    }
    return result;
  }


  /** 
  This method generates and returns a random string of the specified length, composed of uppercase and lowercase letters and digits.

  */

  generateRandomString(length) {
    let result = "";
    let characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  /** 
    This method calculates and returns a Unix timestamp in seconds, either for the current time ("now") or for 30 seconds in the future ("future"). The returned timestamp is used as the           nonce in the request to the Discord API.

  */

  calculateNonce(time) {
    let date = new Date();
    if (time === "now") {
      return Math.round(date.getTime() / 1000);
    }
    if (time === "future") {
      return Math.round(date.setSeconds(date.getSeconds() + 30) / 1000);
    }
  }
}

module.exports = ImagineRequestService;